cmake ./
make
