//
// Created by pultak on 14.01.22.
//

#include "struct.h"

struct_definition::~struct_definition() {
    delete contents;
}
