Slozka documentation obsahuje dokumentaci.

Slozka bin obsahuje spustitelny program FJP_SP, ktery ocekava jako prvni parametr nazev vystupniho souboru a druhy parametr je cesta ke zdrojovemu kodu jazyka STUPYD. Take se zde nachazi slozka 'examples' s priklady zdrojoveho kodu.

Slozka src obsahuje zdrojove kody naseho programu, CMakeLists.txt, priklady zdrojovych kodu jazyka STUPYD a bashovy skript pro preklad.
